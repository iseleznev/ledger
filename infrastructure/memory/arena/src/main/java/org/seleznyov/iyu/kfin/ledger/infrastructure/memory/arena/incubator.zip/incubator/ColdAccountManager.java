package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator;

@Service
public class ColdAccountManager {

    // Обычный thread pool для обработки холодных операций
    private final ExecutorService coldAccountExecutor =
        Executors.newFixedThreadPool(20); // Фиксированный размер

    // Кэш для недавно использованных холодных счетов
    private final LoadingCache<UUID, ColdAccountData> coldAccountCache;

    // Партицированные блокировки для снижения contention
    private final StripedLock accountLocks = Striped.lock(128);

    public ColdAccountManager(ColdAccountRepository repository) {
        this.coldAccountCache = Caffeine.newBuilder()
            .maximumSize(10_000)
            .expireAfterAccess(Duration.ofMinutes(15)) // Короткий TTL
            .build(repository::loadAccount);
    }

    /**
     * Обработка операции для холодного счета
     */
    public CompletableFuture<Boolean> processEntry(UUID accountId, EntryRecord entry) {
        return CompletableFuture.supplyAsync(() -> {

            // Блокировка по аккаунту для консистентности
            Lock accountLock = accountLocks.get(accountId);
            accountLock.lock();

            try {
                // Загружаем данные аккаунта из кэша или БД
                ColdAccountData accountData = coldAccountCache.get(accountId);

                // Обновляем баланс
                accountData.addEntry(entry);

                // Сразу сохраняем в БД (без батчинга)
                repository.saveEntry(entry);
                repository.updateAccountSnapshot(accountData);

                return true;

            } catch (Exception e) {
                log.error("Error processing cold account entry", e);
                return false;
            } finally {
                accountLock.unlock();
            }

        }, coldAccountExecutor);
    }

    /**
     * Получение баланса холодного счета
     */
    public CompletableFuture<Long> getBalance(UUID accountId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                ColdAccountData accountData = coldAccountCache.get(accountId);
                return accountData.getCurrentBalance();
            } catch (Exception e) {
                log.error("Error getting cold account balance", e);
                return 0L;
            }
        }, coldAccountExecutor);
    }
}