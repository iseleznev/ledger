package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

import java.time.Instant;
import java.util.UUID;
import java.util.Objects;

/**
 * Данные батча операций для отправки в PostgreSQL
 */
public class BatchData {

    private final UUID batchId;
    private final UUID accountId;
    private final int entryCount;
    private final long totalDelta;
    private final byte[] data;
    private final Instant createdAt;
    private final long sequenceStart;
    private final long sequenceEnd;
    private final long checksum;
    private volatile BatchStatus status;
    private volatile Instant processedAt;
    private volatile String errorMessage;

    // Конструктор через Builder
    private BatchData(Builder builder) {
        this.batchId = builder.batchId;
        this.accountId = builder.accountId;
        this.entryCount = builder.entryCount;
        this.totalDelta = builder.totalDelta;
        this.data = builder.data != null ? builder.data.clone() : null;
        this.createdAt = builder.createdAt;
        this.sequenceStart = builder.sequenceStart;
        this.sequenceEnd = builder.sequenceEnd;
        this.checksum = builder.checksum;
        this.status = builder.status;
        this.processedAt = builder.processedAt;
        this.errorMessage = builder.errorMessage;
    }

    // ===== GETTERS =====

    public UUID getBatchId() {
        return batchId;
    }

    public UUID getAccountId() {
        return accountId;
    }

    public int getEntryCount() {
        return entryCount;
    }

    public long getTotalDelta() {
        return totalDelta;
    }

    public byte[] getData() {
        return data != null ? data.clone() : null;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public long getSequenceStart() {
        return sequenceStart;
    }

    public long getSequenceEnd() {
        return sequenceEnd;
    }

    public long getChecksum() {
        return checksum;
    }

    public BatchStatus getStatus() {
        return status;
    }

    public Instant getProcessedAt() {
        return processedAt;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    // ===== STATUS MANAGEMENT =====

    public void setStatus(BatchStatus status) {
        this.status = status;
        if (status == BatchStatus.COMPLETED || status == BatchStatus.FAILED) {
            this.processedAt = Instant.now();
        }
    }

    public void markCompleted() {
        setStatus(BatchStatus.COMPLETED);
    }

    public void markFailed(String errorMessage) {
        this.errorMessage = errorMessage;
        setStatus(BatchStatus.FAILED);
    }

    public void markProcessing() {
        setStatus(BatchStatus.PROCESSING);
    }

    // ===== UTILITY METHODS =====

    /**
     * Проверка целостности батча
     */
    public boolean verifyChecksum() {
        if (data == null) {
            return checksum == 0;
        }

        return checksum == calculateDataChecksum(data);
    }

    private static long calculateDataChecksum(byte[] data) {
        long checksum = 0;
        for (int i = 0; i < data.length - 7; i += 8) {
            if (i + 7 < data.length) {
                long value = 0;
                for (int j = 0; j < 8; j++) {
                    value |= ((long) (data[i + j] & 0xFF)) << (j * 8);
                }
                checksum ^= value;
            }
        }
        return checksum;
    }

    /**
     * Размер батча в байтах
     */
    public int getDataSize() {
        return data != null ? data.length : 0;
    }

    /**
     * Проверка валидности батча
     */
    public boolean isValid() {
        return batchId != null &&
            accountId != null &&
            entryCount > 0 &&
            sequenceStart <= sequenceEnd &&
            sequenceEnd - sequenceStart + 1 == entryCount &&
            createdAt != null &&
            verifyChecksum();
    }

    /**
     * Возраст батча в миллисекундах
     */
    public long getAgeMillis() {
        return Instant.now().toEpochMilli() - createdAt.toEpochMilli();
    }

    /**
     * Время обработки в миллисекундах (если завершен)
     */
    public long getProcessingTimeMillis() {
        if (processedAt == null) {
            return -1;
        }
        return processedAt.toEpochMilli() - createdAt.toEpochMilli();
    }

    // ===== BUILDER PATTERN =====

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID batchId;
        private UUID accountId;
        private int entryCount;
        private long totalDelta;
        private byte[] data;
        private Instant createdAt;
        private long sequenceStart;
        private long sequenceEnd;
        private long checksum;
        private BatchStatus status = BatchStatus.READY;
        private Instant processedAt;
        private String errorMessage;

        public Builder batchId(UUID batchId) {
            this.batchId = batchId;
            return this;
        }

        public Builder accountId(UUID accountId) {
            this.accountId = accountId;
            return this;
        }

        public Builder entryCount(int entryCount) {
            this.entryCount = entryCount;
            return this;
        }

        public Builder totalDelta(long totalDelta) {
            this.totalDelta = totalDelta;
            return this;
        }

        public Builder data(byte[] data) {
            this.data = data;
            return this;
        }

        public Builder createdAt(Instant createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder sequenceStart(long sequenceStart) {
            this.sequenceStart = sequenceStart;
            return this;
        }

        public Builder sequenceEnd(long sequenceEnd) {
            this.sequenceEnd = sequenceEnd;
            return this;
        }

        public Builder checksum(long checksum) {
            this.checksum = checksum;
            return this;
        }

        public Builder status(BatchStatus status) {
            this.status = status;
            return this;
        }

        public Builder processedAt(Instant processedAt) {
            this.processedAt = processedAt;
            return this;
        }

        public Builder errorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        public BatchData build() {
            // Автоматическое заполнение полей если не указаны
            if (batchId == null) {
                batchId = UUID.randomUUID();
            }
            if (createdAt == null) {
                createdAt = Instant.now();
            }
            if (data != null && checksum == 0) {
                checksum = calculateDataChecksum(data);
            }

            BatchData batch = new BatchData(this);

            // Валидация
            if (!batch.isValid()) {
                throw new IllegalStateException("Invalid batch data");
            }

            return batch;
        }
    }

    // ===== EQUALS, HASHCODE, TOSTRING =====

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BatchData batchData = (BatchData) o;
        return Objects.equals(batchId, batchData.batchId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(batchId);
    }

    @Override
    public String toString() {
        return String.format(
            "BatchData{batchId=%s, accountId=%s, entryCount=%d, totalDelta=%d, " +
                "status=%s, dataSize=%d, age=%dms}",
            batchId, accountId, entryCount, totalDelta, status, getDataSize(), getAgeMillis()
        );
    }
}