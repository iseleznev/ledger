package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

/**
 * Статусы обработки батча операций
 */
public enum BatchStatus {

    /**
     * Батч создан и готов к обработке
     */
    READY("Готов к обработке"),

    /**
     * Батч взят в обработку
     */
    PROCESSING("Обрабатывается"),

    /**
     * Батч успешно обработан и сохранен в БД
     */
    COMPLETED("Завершен успешно"),

    /**
     * Ошибка при обработке батча
     */
    FAILED("Ошибка обработки"),

    /**
     * Батч отменен (например, при shutdown)
     */
    CANCELLED("Отменен"),

    /**
     * Батч повторно поставлен в очередь после ошибки
     */
    RETRYING("Повторная попытка"),

    /**
     * Батч отложен для повторной обработки
     */
    DELAYED("Отложен");

    private final String description;

    BatchStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Проверяет является ли статус финальным (обработка завершена)
     */
    public boolean isFinal() {
        return this == COMPLETED || this == FAILED || this == CANCELLED;
    }

    /**
     * Проверяет может ли батч быть обработан
     */
    public boolean isProcessable() {
        return this == READY || this == RETRYING;
    }

    /**
     * Проверяет находится ли батч в процессе обработки
     */
    public boolean isInProgress() {
        return this == PROCESSING;
    }

    /**
     * Проверяет нужна ли повторная попытка
     */
    public boolean needsRetry() {
        return this == FAILED || this == DELAYED;
    }

    /**
     * Получение следующего статуса в workflow
     */
    public BatchStatus nextStatus() {
        return switch (this) {
            case READY -> PROCESSING;
            case PROCESSING -> COMPLETED; // Успешный путь
            case FAILED -> RETRYING;
            case RETRYING -> PROCESSING;
            case DELAYED -> READY;
            default -> this; // Финальные статусы не меняются
        };
    }

    /**
     * Получение статуса ошибки
     */
    public BatchStatus errorStatus() {
        return switch (this) {
            case PROCESSING, RETRYING -> FAILED;
            default -> this;
        };
    }

    /**
     * Статистика по группам статусов
     */
    public StatusGroup getGroup() {
        return switch (this) {
            case READY, RETRYING, DELAYED -> StatusGroup.PENDING;
            case PROCESSING -> StatusGroup.ACTIVE;
            case COMPLETED -> StatusGroup.SUCCESS;
            case FAILED, CANCELLED -> StatusGroup.ERROR;
        };
    }

    /**
     * Группы статусов для статистики
     */
    public enum StatusGroup {
        PENDING("Ожидающие"),
        ACTIVE("Активные"),
        SUCCESS("Успешные"),
        ERROR("С ошибками");

        private final String description;

        StatusGroup(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    @Override
    public String toString() {
        return description;
    }
}