package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

import lombok.Builder;

/**
 * Метрики аккаунта
 */
@Builder
public record AccountMetrics(
    UUID accountId,
    int currentBatchSize,
    long snapshotBalance,
    long snapshotSequence,
    long lastTransactionId,
    long lastAccessTime,
    RingBufferMetrics ringBufferMetrics,
    long memoryUsageBytes,
    boolean isShutdownRequested
) {

    /**
     * Возраст последнего доступа в миллисекундах
     */
    public long getLastAccessAgeMillis() {
        return System.currentTimeMillis() - lastAccessTime;
    }

    /**
     * Проверка активности аккаунта
     */
    public boolean isActive(long inactiveThresholdMs) {
        return getLastAccessAgeMillis() < inactiveThresholdMs;
    }

    /**
     * Уровень активности аккаунта
     */
    public ActivityLevel getActivityLevel() {
        long ageMinutes = getLastAccessAgeMillis() / (1000 * 60);

        if (ageMinutes < 1) return ActivityLevel.VERY_HIGH;
        if (ageMinutes < 5) return ActivityLevel.HIGH;
        if (ageMinutes < 30) return ActivityLevel.MEDIUM;
        if (ageMinutes < 120) return ActivityLevel.LOW;
        return ActivityLevel.INACTIVE;
    }

    public enum ActivityLevel {
        VERY_HIGH, HIGH, MEDIUM, LOW, INACTIVE
    }

    /**
     * Создание недоступных метрик
     */
    public static AccountMetrics unavailable() {
        return AccountMetrics.builder()
            .accountId(UUID.randomUUID())
            .currentBatchSize(-1)
            .snapshotBalance(0)
            .snapshotSequence(0)
            .lastTransactionId(0)
            .lastAccessTime(0)
            .ringBufferMetrics(null)
            .memoryUsageBytes(0)
            .isShutdownRequested(true)
            .build();
    }

    @Override
    public String toString() {
        return String.format(
            "AccountMetrics{account=%s, batchSize=%d, balance=%d, " +
                "activity=%s, memory=%d bytes, ringBuffer=%s}",
            accountId.toString().substring(0, 8),
            currentBatchSize, snapshotBalance,
            getActivityLevel(), memoryUsageBytes,
            ringBufferMetrics != null ? ringBufferMetrics.getLoadLevel() : "N/A"
        );
    }
}
