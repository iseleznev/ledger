package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

import lombok.Builder;

/**
 * Метрики менеджера горячих аккаунтов
 */
@Builder
public record HotAccountManagerMetrics(
    int activeHotAccounts,
    long totalOperationsProcessed,
    long totalAccountsCreated,
    long memoryUsageBytes
) {

    /**
     * Средний размер памяти на аккаунт
     */
    public long getAverageMemoryPerAccount() {
        return activeHotAccounts > 0 ? memoryUsageBytes / activeHotAccounts : 0;
    }

    /**
     * Средняя производительность
     */
    public double getAverageOpsPerAccount() {
        return activeHotAccounts > 0 ? (double) totalOperationsProcessed / activeHotAccounts : 0.0;
    }

    @Override
    public String toString() {
        return String.format(
            "HotAccountManagerMetrics{accounts=%d, totalOps=%d, memory=%d MB, " +
                "avgMemory=%d KB/account, avgOps=%.1f/account}",
            activeHotAccounts, totalOperationsProcessed, memoryUsageBytes / (1024 * 1024),
            getAverageMemoryPerAccount() / 1024, getAverageOpsPerAccount()
        );
    }
}
