package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

import lombok.Builder;

/**
 * Метрики Ring Buffer
 */
@Builder
public record RingBufferMetrics(
    int capacity,
    int currentSize,
    long writeSequence,
    long readSequence,
    double utilizationPercent,
    long totalPublished,
    long totalConsumed,
    long publishFailures,
    double successRate,
    double throughputOpsPerSecond
) {

    /**
     * Проверка здоровья ring buffer
     */
    public boolean isHealthy() {
        return utilizationPercent < 90.0 && // Не переполнен
            successRate > 95.0 &&        // Высокий success rate
            readSequence <= writeSequence; // Корректные sequences
    }

    /**
     * Уровень загрузки
     */
    public LoadLevel getLoadLevel() {
        if (utilizationPercent < 50.0) return LoadLevel.LOW;
        if (utilizationPercent < 80.0) return LoadLevel.MEDIUM;
        if (utilizationPercent < 95.0) return LoadLevel.HIGH;
        return LoadLevel.CRITICAL;
    }

    public enum LoadLevel {
        LOW, MEDIUM, HIGH, CRITICAL
    }

    @Override
    public String toString() {
        return String.format(
            "RingBufferMetrics{size=%d/%d (%.1f%%), published=%d, consumed=%d, " +
                "failures=%d (%.1f%%), throughput=%.1f ops/sec}",
            currentSize, capacity, utilizationPercent,
            totalPublished, totalConsumed,
            publishFailures, 100.0 - successRate, throughputOpsPerSecond
        );
    }
}

