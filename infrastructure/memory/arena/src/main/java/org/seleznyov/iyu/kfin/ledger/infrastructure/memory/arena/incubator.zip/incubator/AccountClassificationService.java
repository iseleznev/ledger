package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator;

import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class AccountClassificationService {

    private final Set<UUID> hotAccountIds = ConcurrentHashMap.newKeySet();
    private final AccountMetricsService metricsService;

    /**
     * Определение типа аккаунта на основе активности
     */
    public boolean isHotAccount(UUID accountId) {
        // Статический список горячих аккаунтов
        if (hotAccountIds.contains(accountId)) {
            return true;
        }

        // Динамическая классификация по метрикам
        AccountActivityMetrics metrics = metricsService.getRecentActivity(accountId);

        return metrics.getOperationsPerMinute() > 10 || // > 10 операций в минуту
            metrics.getOperationsPerHour() > 100 ||   // > 100 операций в час
            metrics.hasRecentBurstActivity();         // Недавние всплески активности
    }

    /**
     * Миграция аккаунта из cold в hot
     */
    public void promoteToHot(UUID accountId) {
        hotAccountIds.add(accountId);
        log.info("Promoted account {} to hot", accountId);
    }

    /**
     * Миграция аккаунта из hot в cold
     */
    public void demoteToCore(UUID accountId) {
        hotAccountIds.remove(accountId);
        log.info("Demoted account {} to cold", accountId);
    }
}