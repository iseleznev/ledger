package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

@Component
@Slf4j
public class PostgresBatchRingBufferManager {

    private final PostgresBatchRingBuffer ringBuffer;
    private final List<Thread> postgresWorkers = new ArrayList<>();
    private final AtomicBoolean running = new AtomicBoolean(true);
    private final JdbcTemplate jdbcTemplate;

    // Метрики
    private final AtomicLong totalBatchesReceived = new AtomicLong(0);
    private final AtomicLong totalBatchesProcessed = new AtomicLong(0);
    private final AtomicLong totalBatchesFailed = new AtomicLong(0);

    public PostgresBatchRingBufferManager(JdbcTemplate jdbcTemplate,
                                          @Value("${ledger.postgres.ring-buffer.size:8192}") int ringBufferSize,
                                          @Value("${ledger.postgres.workers.count:4}") int workerCount) {
        this.jdbcTemplate = jdbcTemplate;
        this.ringBuffer = new PostgresBatchRingBuffer(ringBufferSize);

        startPostgresWorkers(workerCount);

        log.info("PostgresBatchRingBufferManager initialized: buffer_size={}, workers={}",
            ringBufferSize, workerCount);
    }

    /**
     * ✅ Метод вызываемый BatchSender'ом
     */
    public boolean submitBatch(BatchData batch) {
        if (!running.get()) {
            log.warn("PostgresBatchRingBufferManager is shutting down, rejecting batch {}",
                batch.getBatchId());
            return false;
        }

        totalBatchesReceived.incrementAndGet();

        try {
            // ✅ Пытаемся отправить в ring buffer с backoff
            boolean sent = submitBatchWithBackoff(batch);

            if (sent) {
                log.debug("Successfully submitted batch {} to PostgreSQL ring buffer",
                    batch.getBatchId());
                return true;
            } else {
                totalBatchesFailed.incrementAndGet();
                log.error("Failed to submit batch {} to PostgreSQL ring buffer after retries",
                    batch.getBatchId());
                return false;
            }

        } catch (Exception e) {
            totalBatchesFailed.incrementAndGet();
            log.error("Exception while submitting batch {} to PostgreSQL ring buffer",
                batch.getBatchId(), e);
            return false;
        }
    }

    private boolean submitBatchWithBackoff(BatchData batch) {
        int maxRetries = 50;
        long baseBackoffNanos = 1_000L; // 1μs

        for (int attempt = 1; attempt <= maxRetries; attempt++) {

            if (ringBuffer.tryPublish(batch)) {
                if (attempt > 1) {
                    log.debug("Batch {} submitted on attempt {}", batch.getBatchId(), attempt);
                }
                return true;
            }

            // Ring buffer полный - backoff
            if (attempt < maxRetries) {
                long backoffNanos = baseBackoffNanos * (1L << Math.min(attempt - 1, 10));
                LockSupport.parkNanos(backoffNanos);

                if (!running.get()) {
                    log.warn("Shutdown during batch submission for batch {}", batch.getBatchId());
                    return false;
                }
            }
        }

        log.error("Failed to submit batch {} after {} attempts", batch.getBatchId(), maxRetries);
        return false;
    }

    private void startPostgresWorkers(int workerCount) {
        for (int i = 0; i < workerCount; i++) {
            final int workerId = i;

            Thread worker = Thread.ofVirtual()
                .name("postgres-worker-" + workerId)
                .start(() -> processPostgresBatchesLoop(workerId));

            postgresWorkers.add(worker);

            log.debug("Started PostgreSQL worker {}", workerId);
        }
    }

    /**
     * ✅ Основной цикл PostgreSQL worker'а
     */
    private void processPostgresBatchesLoop(int workerId) {
        log.info("PostgreSQL worker {} started", workerId);

        while (running.get()) {
            try {
                // ✅ Читаем BatchData из ring buffer
                BatchData batch = ringBuffer.poll(1, TimeUnit.SECONDS);

                if (batch != null) {
                    log.debug("Worker {} processing batch {} from account {}: {} entries",
                        workerId, batch.getBatchId(), batch.getAccountId(), batch.getEntryCount());

                    processBatchInPostgres(batch, workerId);

                } else {
                    log.trace("Worker {} idle - no batches available", workerId);
                }

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                log.error("Unexpected error in PostgreSQL worker {}", workerId, e);
            }
        }

        log.info("PostgreSQL worker {} stopped", workerId);
    }

    private void processBatchInPostgres(BatchData batch, int workerId) {
        long startTime = System.nanoTime();

        try {
            batch.markProcessing();

            // ✅ Десериализуем entries из BatchData
            List<EntryRecord> entries = deserializeBatchEntries(batch);

            log.debug("Worker {} inserting {} entries from batch {} (account {}) into PostgreSQL",
                workerId, entries.size(), batch.getBatchId(), batch.getAccountId());

            // ✅ Выполняем COPY FROM с commit
            int insertedRows = performCopyFromInsert(entries);

            if (insertedRows == batch.getEntryCount()) {
                batch.markCompleted();
                totalBatchesProcessed.incrementAndGet();

                long durationMs = (System.nanoTime() - startTime) / 1_000_000;
                log.debug("Worker {} completed batch {}: {} entries in {} ms",
                    workerId, batch.getBatchId(), insertedRows, durationMs);
            } else {
                String error = String.format("Insert count mismatch: expected=%d, actual=%d",
                    batch.getEntryCount(), insertedRows);
                batch.markFailed(error);
                totalBatchesFailed.incrementAndGet();
                log.error("Worker {} failed batch {}: {}", workerId, batch.getBatchId(), error);
            }

        } catch (Exception e) {
            batch.markFailed(e.getMessage());
            totalBatchesFailed.incrementAndGet();

            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            log.error("Worker {} error processing batch {} after {} ms",
                workerId, batch.getBatchId(), durationMs, e);
        }
    }

    /**
     * ✅ COPY FROM insert с explicit commit
     */
    private int performCopyFromInsert(List<EntryRecord> entries) throws SQLException, IOException {

        String copySQL = """
            COPY ledger.entry_records 
            (id, account_id, transaction_id, entry_type, amount, 
             created_at_millis, operation_date_epoch_day, idempotency_key, 
             currency_code, entry_ordinal)
            FROM STDIN WITH (FORMAT BINARY)
            """;

        try (Connection connection = jdbcTemplate.getDataSource().getConnection()) {

            // ✅ Отключаем autoCommit
            connection.setAutoCommit(false);

            PGConnection pgConnection = connection.unwrap(PGConnection.class);
            CopyManager copyManager = pgConnection.getCopyAPI();

            // ✅ Генерируем binary данные
            byte[] binaryData = generateHybridBinaryData(entries);

            // ✅ COPY FROM
            long insertedRows = copyManager.copyIn(copySQL, new ByteArrayInputStream(binaryData));

            // ✅ ОБЯЗАТЕЛЬНЫЙ commit
            connection.commit();

            return (int) insertedRows;

        } catch (SQLException | IOException e) {
            log.error("Error during COPY FROM for {} entries", entries.size(), e);
            throw e;
        }
    }

    // ===== METRICS =====

    public PostgresMetrics getMetrics() {
        return PostgresMetrics.builder()
            .totalBatchesReceived(totalBatchesReceived.get())
            .totalBatchesProcessed(totalBatchesProcessed.get())
            .totalBatchesFailed(totalBatchesFailed.get())
            .ringBufferSize(ringBuffer.size())
            .ringBufferCapacity(ringBuffer.capacity())
            .ringBufferUtilization(ringBuffer.getUtilization())
            .workerCount(postgresWorkers.size())
            .build();
    }

    // ===== SHUTDOWN =====

    @PreDestroy
    public void shutdown() {
        log.info("Shutting down PostgresBatchRingBufferManager...");

        running.set(false);

        // Interrupt workers
        postgresWorkers.forEach(Thread::interrupt);

        // Wait for graceful shutdown
        for (Thread worker : postgresWorkers) {
            try {
                worker.join(5000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }

        log.info("PostgresBatchRingBufferManager shutdown completed");
    }
}