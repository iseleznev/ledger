package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator;

import lombok.Data;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;

import java.lang.foreign.MemorySegment;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Data
@Accessors(fluent = true)
public class EntriesSnapshotPostgresProcessor {

    private final javax.sql.DataSource dataSource;

    public EntriesSnapshotPostgresProcessor(javax.sql.DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * ✅ Отправка snapshot batch в PostgreSQL
     */
    public CompletableFuture<Boolean> submitSnapshotBatch(MemorySegment snapshotData, int snapshotCount) {

        return CompletableFuture.supplyAsync(() -> {
            try {
                String copySQL = """
                        COPY ledger.account_snapshots 
                        (snapshot_id, account_id, balance, entry_count, sequence_number, 
                         trigger_type, created_at_millis, duration_millis)
                        FROM STDIN WITH (FORMAT BINARY)
                        """;

                try (java.sql.Connection connection = dataSource.getConnection()) {
                    connection.setAutoCommit(false);

                    org.postgresql.PGConnection pgConnection = connection.unwrap(org.postgresql.PGConnection.class);

                    // Используем тот же подход что и для entries
                    java.lang.reflect.Method getQueryExecutorMethod = pgConnection.getClass().getMethod("getQueryExecutor");
                    Object queryExecutor = getQueryExecutorMethod.invoke(pgConnection);

                    // Send COPY command
                    java.lang.reflect.Method sendQueryMethod = queryExecutor.getClass().getMethod("sendQuery", String.class);
                    sendQueryMethod.invoke(queryExecutor, copySQL);

                    // Send data
                    sendSnapshotDataDirect(queryExecutor, snapshotData);

                    // End COPY
                    java.lang.reflect.Method endCopyMethod = queryExecutor.getClass().getMethod("endCopy");
                    long insertedRows = (Long) endCopyMethod.invoke(queryExecutor);

                    connection.commit();

                    log.debug("Successfully inserted {} snapshots to PostgreSQL", insertedRows);
                    return insertedRows == snapshotCount;

                }

            } catch (Exception e) {
                log.error("Error inserting snapshot batch", e);
                return false;
            }
        });
    }

    private void sendSnapshotDataDirect(Object queryExecutor, MemorySegment snapshotData) throws Exception {

        // Добавляем PostgreSQL header
        byte[] postgresHeader = generateSnapshotPostgresHeader();

        java.lang.reflect.Method sendCopyDataMethod = queryExecutor.getClass()
            .getMethod("sendCopyData", byte[].class, int.class, int.class);

        // Send header
        sendCopyDataMethod.invoke(queryExecutor, postgresHeader, 0, postgresHeader.length);

        // Send data in chunks
        long totalSize = snapshotData.byteSize();
        long sent = 0;
        int chunkSize = 64 * 1024; // 64KB chunks для snapshots
        byte[] chunk = new byte[chunkSize];

        while (sent < totalSize) {
            long remainingSize = totalSize - sent;
            int currentChunkSize = (int) Math.min(remainingSize, chunkSize);

            // Copy from MemorySegment to chunk
            MemorySegment.copy(
                snapshotData.asSlice(sent, currentChunkSize), 0,
                MemorySegment.ofArray(chunk), 0,
                currentChunkSize
            );

            sendCopyDataMethod.invoke(queryExecutor, chunk, 0, currentChunkSize);
            sent += currentChunkSize;
        }

        // Send terminator
        byte[] terminator = {-1, -1};
        sendCopyDataMethod.invoke(queryExecutor, terminator, 0, 2);
    }

    private byte[] generateSnapshotPostgresHeader() {
        // PostgreSQL binary header для snapshots
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        java.io.DataOutputStream dos = new java.io.DataOutputStream(baos);

        try {
            dos.writeBytes("PGCOPY\n\377\r\n\0");
            dos.writeInt(0); // flags
            dos.writeInt(0); // extension
        } catch (java.io.IOException e) {
            throw new RuntimeException("Failed to generate snapshot header", e);
        }

        return baos.toByteArray();
    }
}
