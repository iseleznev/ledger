package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

/**
 * Исключение при переполнении buffer
 */
public class BufferFullException extends RuntimeException {

    public BufferFullException(String message) {
        super(message);
    }

    public BufferFullException(String message, Throwable cause) {
        super(message, cause);
    }
}
