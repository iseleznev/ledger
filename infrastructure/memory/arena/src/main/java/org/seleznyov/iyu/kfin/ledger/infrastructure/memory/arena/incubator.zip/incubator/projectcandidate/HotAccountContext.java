package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

import lombok.extern.slf4j.Slf4j;
import org.seleznyov.iyu.kfin.ledger.domain.model.entryrecord.EntryRecord;

import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.ValueLayout;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

@Slf4j
public class HotAccountContext {

    // ===== КОНСТАНТЫ =====
    private static final int MAX_BATCH_SIZE = 1000;
    private static final long ENTRY_SIZE = 64; // Размер одной проводки в байтах
    private static final int RING_BUFFER_SIZE = 2048;
    private static final long IDLE_FLUSH_THRESHOLD_MS = 5000;
//    private static final VectorSpecies<Long> LONG_SPECIES = LongVector.SPECIES_PREFERRED;
//    private static final int VECTOR_LENGTH = LONG_SPECIES.length();

    // ===== ОСНОВНЫЕ ПОЛЯ =====
    private final UUID accountId;
    private final Arena sharedArena;
    private final MemorySegment batchSegment;        // ✅ Инициализируется в конструкторе
    private final MemorySegment amountArraySegment;  // ✅ Инициализируется в конструкторе
    private final AccountOperationRingBuffer operationBuffer;
    private final CompletableFuture<Void> processingTask;

    // ===== СОСТОЯНИЕ =====
    private int currentBatchSize = 0;
    private long snapshotBalance = 0L;
    private long snapshotSequence = 0L;
    private long lastTransactionId = 0L;

    // ===== МЕЖПОТОЧНЫЕ ПЕРЕМЕННЫЕ =====
    private volatile boolean shutdownRequested = false;
    private volatile long lastAccessTime = System.currentTimeMillis();
    private volatile Thread dedicatedThread;

    // ===== КОНСТРУКТОР =====
    public HotAccountContext(UUID accountId) {
        this.accountId = accountId;
        this.sharedArena = Arena.ofShared(); // Shared для миграции между carrier threads
        this.operationBuffer = new AccountOperationRingBuffer(RING_BUFFER_SIZE);

        // ✅ ИНИЦИАЛИЗАЦИЯ MEMORY SEGMENTS
        initializeMemorySegments();

        // Загрузка снапшота из БД
        loadSnapshotFromDatabase();

        // Запуск dedicated виртуального потока
        this.processingTask = CompletableFuture.runAsync(
            this::processAccountOperations,
            Executors.newVirtualThreadPerTaskExecutor()
        );

        log.info("Created HotAccountContext for account {}", accountId);
    }

    // ✅ ПОЛНАЯ РЕАЛИЗАЦИЯ ИНИЦИАЛИЗАЦИИ ПАМЯТИ
    private void initializeMemorySegments() {
        try {
            // 1. Выделяем память для основного батча проводок
            long totalBatchSize = MAX_BATCH_SIZE * ENTRY_SIZE;
            this.batchSegment = sharedArena.allocate(totalBatchSize, 64); // Cache line alignment
            batchSegment.fill((byte) 0);

            log.debug("Allocated batchSegment for account {}: {} bytes at address 0x{}",
                accountId, totalBatchSize, Long.toHexString(batchSegment.address()));

            // 2. Выделяем выровненный массив сумм для SIMD операций
            int alignedSize = alignToVectorBoundary(MAX_BATCH_SIZE);
            long amountArraySize = alignedSize * Long.BYTES;
            this.amountArraySegment = sharedArena.allocate(amountArraySize, 64);
            amountArraySegment.fill((byte) 0);

            log.debug("Allocated amountArraySegment for account {}: {} bytes (aligned to {} elements) at address 0x{}",
                accountId, amountArraySize, alignedSize, Long.toHexString(amountArraySegment.address()));

            // 3. Валидация выравнивания для SIMD
            validateSIMDAlignment();

            log.info("Successfully initialized memory segments for account {}", accountId);

        } catch (Exception e) {
            log.error("Failed to initialize memory segments for account {}", accountId, e);
            throw new RuntimeException("Memory initialization failed", e);
        }
    }

    private int alignToVectorBoundary(int size) {
        return ((size + VECTOR_LENGTH - 1) / VECTOR_LENGTH) * VECTOR_LENGTH;
    }

    private void validateSIMDAlignment() {
        // Проверяем выравнивание batchSegment
        long batchAddress = batchSegment.address();
        if (batchAddress % 64 != 0) {
            throw new IllegalStateException(
                String.format("batchSegment not aligned to 64 bytes. Address: 0x%x", batchAddress));
        }

        // Проверяем выравнивание amountArraySegment
        long amountAddress = amountArraySegment.address();
        if (amountAddress % 64 != 0) {
            throw new IllegalStateException(
                String.format("amountArraySegment not aligned to 64 bytes. Address: 0x%x", amountAddress));
        }

        // Проверяем размер amountArraySegment кратен векторной длине
        long amountSize = amountArraySegment.byteSize();
        long expectedElements = amountSize / Long.BYTES;
        if (expectedElements % VECTOR_LENGTH != 0) {
            throw new IllegalStateException(
                String.format("amountArraySegment size not aligned to vector length. " +
                    "Elements: %d, Vector length: %d", expectedElements, VECTOR_LENGTH));
        }

        log.debug("SIMD alignment validated for account {}: batch=0x{}, amount=0x{}",
            accountId, Long.toHexString(batchAddress), Long.toHexString(amountAddress));
    }

    // ===== ОСТАЛЬНЫЕ МЕТОДЫ БЕЗ ИЗМЕНЕНИЙ =====

    private void loadSnapshotFromDatabase() {
        // TODO: Реальная загрузка из БД
        this.snapshotBalance = 0L;
        this.snapshotSequence = 0L;

        log.debug("Loaded snapshot for account {}: balance={}, sequence={}",
            accountId, snapshotBalance, snapshotSequence);
    }

    // ===== PUBLIC API =====

    public CompletableFuture<Boolean> submitOperation(AccountOperation operation) {
        if (shutdownRequested) {
            return CompletableFuture.failedFuture(
                new IllegalStateException("Account context is shutting down"));
        }

        lastAccessTime = System.currentTimeMillis();

        if (operationBuffer.tryPublish(operation)) {
            return operation.getResult();
        } else {
            return CompletableFuture.failedFuture(
                new BufferFullException("Account operation buffer is full for " + accountId));
        }
    }

    public CompletableFuture<Boolean> addEntry(EntryRecord entry) {
        AccountOperation operation = new AccountOperation(OperationType.ADD_ENTRY, entry);
        return submitOperation(operation);
    }

    public CompletableFuture<Long> getCurrentBalance() {
        AccountOperation operation = new AccountOperation(OperationType.GET_BALANCE, null);
        return submitOperation(operation).thenCompose(success -> operation.getResult());
    }

    public CompletableFuture<Boolean> flushBatch() {
        AccountOperation operation = new AccountOperation(OperationType.FLUSH_BATCH, null);
        return submitOperation(operation);
    }

    public CompletableFuture<AccountMetrics> getMetrics() {
        AccountOperation operation = new AccountOperation(OperationType.GET_METRICS, null);
        return submitOperation(operation).thenCompose(success -> operation.getResult());
    }

    public void shutdown() {
        log.info("Shutting down HotAccountContext for account {}", accountId);

        shutdownRequested = true;

        Thread thread = dedicatedThread;
        if (thread != null) {
            LockSupport.unpark(thread);
        }

        try {
            processingTask.get(10, TimeUnit.SECONDS);
        } catch (Exception e) {
            log.error("Error during shutdown of account {}", accountId, e);
            processingTask.cancel(true);
        }
    }

    public boolean isIdle(long idleThresholdMs) {
        return System.currentTimeMillis() - lastAccessTime > idleThresholdMs;
    }

    // ===== DEDICATED VIRTUAL THREAD PROCESSING =====

    private void processAccountOperations() {
        dedicatedThread = Thread.currentThread();
        Thread.currentThread().setName("hot-account-" + accountId.toString().substring(0, 8));

        log.info("Started processing operations for account {}", accountId);

        try {
            while (!shutdownRequested) {
                try {
                    AccountOperation operation = operationBuffer.poll(1, TimeUnit.SECONDS);

                    if (operation != null) {
                        processOperationLockFree(operation);
                    } else {
                        checkPeriodicFlush();
                    }

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        } finally {
            performFinalCleanup();
            dedicatedThread = null;
            log.info("Stopped processing operations for account {}", accountId);
        }
    }

    private void processOperationLockFree(AccountOperation operation) {
        try {
            switch (operation.getType()) {
                case ADD_ENTRY -> {
                    EntryRecord entry = operation.getEntry();

                    if (currentBatchSize >= MAX_BATCH_SIZE) {
                        flushCurrentBatch();
                    }

                    addEntryToBatch(entry);
                    currentBatchSize++;
                    lastTransactionId = entry.getTransactionId();

                    operation.complete(true);
                }

                case GET_BALANCE -> {
                    long currentBalance = calculateCurrentBalanceSIMD();
                    operation.complete(currentBalance);
                }

                case FLUSH_BATCH -> {
                    flushCurrentBatch();
                    operation.complete(true);
                }

                case GET_METRICS -> {
                    AccountMetrics metrics = createAccountMetrics();
                    operation.complete(metrics);
                }

                default -> {
                    operation.completeExceptionally(
                        new UnsupportedOperationException("Unknown operation type: " + operation.getType()));
                }
            }
        } catch (Exception e) {
            log.error("Error processing operation for account {}", accountId, e);
            operation.completeExceptionally(e);
        }
    }

    // ✅ ИСПРАВЛЕННЫЕ МЕТОДЫ РАБОТЫ С MEMORY SEGMENTS

    private void addEntryToBatch(EntryRecord entry) {
        long entryOffset = currentBatchSize * ENTRY_SIZE;
        long amountOffset = currentBatchSize * Long.BYTES;

        // ✅ Используем инициализированные segments
        writeEntryToMemory(entry, entryOffset);
        amountArraySegment.set(ValueLayout.JAVA_LONG, amountOffset, entry.getAmount());

        log.trace("Added entry to batch for account {}: amount={}, batch_size={}",
            accountId, entry.getAmount(), currentBatchSize + 1);
    }

    private void writeEntryToMemory(EntryRecord entry, long offset) {
        // ✅ Используем инициализированный batchSegment
        batchSegment.set(ValueLayout.JAVA_LONG, offset + 0, entry.getAmount());
        batchSegment.set(ValueLayout.JAVA_LONG, offset + 8, entry.getTimestamp().toEpochMilli());
        batchSegment.set(ValueLayout.JAVA_LONG, offset + 16, entry.getAccountId().getMostSignificantBits());
        batchSegment.set(ValueLayout.JAVA_LONG, offset + 24, entry.getAccountId().getLeastSignificantBits());
        batchSegment.set(ValueLayout.JAVA_LONG, offset + 32, entry.getTransactionId());
        batchSegment.set(ValueLayout.JAVA_INT, offset + 40, entry.getEntryType().ordinal());
        // Остальные поля и padding...
    }

    private long calculateCurrentBalanceSIMD() {
        long batchDelta = calculateBatchDeltaSIMD();
        return snapshotBalance + batchDelta;
    }

    private long calculateBatchDeltaSIMD() {
        if (currentBatchSize == 0) {
            return 0L;
        }

        LongVector accumulator = LongVector.zero(LONG_SPECIES);

        // Векторизованная часть - используем инициализированный amountArraySegment
        int vectorizedCount = (currentBatchSize / VECTOR_LENGTH) * VECTOR_LENGTH;

        for (int i = 0; i < vectorizedCount; i += VECTOR_LENGTH) {
            long byteOffset = i * Long.BYTES;

            // ✅ Используем инициализированный amountArraySegment
            LongVector amountVector = LongVector.fromMemorySegment(
                LONG_SPECIES, amountArraySegment, byteOffset, ByteOrder.nativeOrder());

            accumulator = accumulator.add(amountVector);
        }

        long vectorSum = accumulator.reduceLanes(VectorOperators.ADD);

        // Обрабатываем остаток скалярно
        long remainderSum = 0;
        for (int i = vectorizedCount; i < currentBatchSize; i++) {
            long byteOffset = i * Long.BYTES;
            remainderSum += amountArraySegment.get(ValueLayout.JAVA_LONG, byteOffset);
        }

        long totalDelta = vectorSum + remainderSum;

        log.trace("Calculated batch delta for account {}: vector_sum={}, remainder_sum={}, total={}",
            accountId, vectorSum, remainderSum, totalDelta);

        return totalDelta;
    }

    private void clearBatch() {
        currentBatchSize = 0;

        // ✅ Используем инициализированные segments для очистки
        batchSegment.fill((byte) 0);
        amountArraySegment.fill((byte) 0);
    }

    private void checkPeriodicFlush() {
        if (currentBatchSize > 0) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastAccessTime > IDLE_FLUSH_THRESHOLD_MS) {
                log.debug("Performing periodic flush for idle account {}", accountId);
                flushCurrentBatch();
            }
        }
    }

    private void flushCurrentBatch() {
        if (currentBatchSize == 0) {
            return;
        }

        log.debug("Flushing batch for account {}: size={}", accountId, currentBatchSize);

        try {
            long batchDelta = calculateBatchDeltaSIMD();
            BatchData batch = createBatchData(batchDelta);
            sendBatchToPostgresRingBuffer(batch);
            updateSnapshot(batchDelta);
            clearBatch();

            log.debug("Successfully flushed batch for account {}: delta={}, new_balance={}",
                accountId, batchDelta, snapshotBalance);

        } catch (Exception e) {
            log.error("Error flushing batch for account {}", accountId, e);
            throw e;
        }
    }

    private BatchData createBatchData(long batchDelta) {
        // ✅ Используем инициализированный batchSegment
        byte[] serializedData = new byte[currentBatchSize * (int) ENTRY_SIZE];

        MemorySegment sourceSegment = batchSegment.asSlice(0, currentBatchSize * ENTRY_SIZE);
        MemorySegment targetSegment = MemorySegment.ofArray(serializedData);

        MemorySegment.copy(sourceSegment, 0, targetSegment, 0, serializedData.length);

        return BatchData.builder()
            .batchId(UUID.randomUUID())
            .accountId(accountId)
            .entryCount(currentBatchSize)
            .totalDelta(batchDelta)
            .data(serializedData)
            .createdAt(Instant.now())
            .status(BatchStatus.READY)
            .checksum(calculateChecksum(serializedData))
            .sequenceStart(snapshotSequence + 1)
            .sequenceEnd(snapshotSequence + currentBatchSize)
            .build();
    }

    private long calculateChecksum(byte[] data) {
        long checksum = 0;
        for (int i = 0; i < data.length - 7; i += 8) {
            long value = MemorySegment.ofArray(data)
                .get(ValueLayout.JAVA_LONG, i);
            checksum ^= value;
        }
        return checksum;
    }

    private void sendBatchToPostgresRingBuffer(BatchData batch) {
        // TODO: Интеграция с PostgreSQL ring buffer
        log.debug("Sent batch to PostgreSQL ring buffer: {}", batch.getBatchId());
    }

    private void updateSnapshot(long batchDelta) {
        snapshotBalance += batchDelta;
        snapshotSequence += currentBatchSize;
        saveSnapshotAsync();
    }

    private void saveSnapshotAsync() {
        long currentBalance = snapshotBalance;
        long currentSequence = snapshotSequence;

        CompletableFuture.runAsync(() -> {
            try {
                // TODO: Реальное сохранение в БД
                log.trace("Saved snapshot for account {}: balance={}, sequence={}",
                    accountId, currentBalance, currentSequence);
            } catch (Exception e) {
                log.error("Failed to save snapshot for account {}", accountId, e);
            }
        });
    }

    private AccountMetrics createAccountMetrics() {
        RingBufferMetrics ringMetrics = operationBuffer.getMetrics();

        return AccountMetrics.builder()
            .accountId(accountId)
            .currentBatchSize(currentBatchSize)
            .snapshotBalance(snapshotBalance)
            .snapshotSequence(snapshotSequence)
            .lastTransactionId(lastTransactionId)
            .lastAccessTime(lastAccessTime)
            .ringBufferMetrics(ringMetrics)
            .memoryUsageBytes(calculateMemoryUsage())
            .isShutdownRequested(shutdownRequested)
            .build();
    }

    private long calculateMemoryUsage() {
        // ✅ Используем инициализированные segments
        return batchSegment.byteSize() + amountArraySegment.byteSize();
    }

    private void performFinalCleanup() {
        try {
            if (currentBatchSize > 0) {
                flushCurrentBatch();
            }

            // ✅ Закрываем Arena что автоматически освободит все segments
            if (sharedArena.scope().isAlive()) {
                sharedArena.close();
                log.debug("Closed Arena for account {}", accountId);
            }

        } catch (Exception e) {
            log.error("Error during final cleanup for account {}", accountId, e);
        }
    }
}