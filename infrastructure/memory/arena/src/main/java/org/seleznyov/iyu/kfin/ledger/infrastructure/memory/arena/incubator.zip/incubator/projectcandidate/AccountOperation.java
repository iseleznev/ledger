package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

/**
 * Операция для аккаунта
 */
public class AccountOperation {

    private final OperationType type;
    private final EntryRecord entry;
    private final CompletableFuture<Object> result;
    private final Instant createdAt;
    private final UUID operationId;

    public AccountOperation(OperationType type, EntryRecord entry) {
        this(type, entry, new CompletableFuture<>());
    }

    public AccountOperation(OperationType type, EntryRecord entry, CompletableFuture<Object> result) {
        this.type = Objects.requireNonNull(type, "Operation type cannot be null");
        this.entry = entry;
        this.result = Objects.requireNonNull(result, "Result future cannot be null");
        this.createdAt = Instant.now();
        this.operationId = UUID.randomUUID();
    }

    // ===== GETTERS =====

    public OperationType getType() {
        return type;
    }

    public EntryRecord getEntry() {
        return entry;
    }

    @SuppressWarnings("unchecked")
    public <T> CompletableFuture<T> getResult() {
        return (CompletableFuture<T>) result;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public UUID getOperationId() {
        return operationId;
    }

    // ===== COMPLETION METHODS =====

    public void complete(Object value) {
        result.complete(value);
    }

    public void completeExceptionally(Throwable throwable) {
        result.completeExceptionally(throwable);
    }

    public boolean isDone() {
        return result.isDone();
    }

    public boolean isCompletedExceptionally() {
        return result.isCompletedExceptionally();
    }

    // ===== UTILITY METHODS =====

    /**
     * Возраст операции в миллисекундах
     */
    public long getAgeMillis() {
        return Instant.now().toEpochMilli() - createdAt.toEpochMilli();
    }

    /**
     * Проверка на timeout
     */
    public boolean isTimedOut(long timeoutMs) {
        return getAgeMillis() > timeoutMs;
    }

    /**
     * Создание специальной операции для пробуждения
     */
    public static AccountOperation createWakeup() {
        return new AccountOperation(OperationType.WAKEUP, null);
    }

    /**
     * Создание операции shutdown
     */
    public static AccountOperation createShutdown() {
        return new AccountOperation(OperationType.SHUTDOWN, null);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountOperation that = (AccountOperation) o;
        return Objects.equals(operationId, that.operationId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(operationId);
    }

    @Override
    public String toString() {
        return String.format(
            "AccountOperation{id=%s, type=%s, age=%dms, done=%s}",
            operationId.toString().substring(0, 8),
            type, getAgeMillis(), isDone()
        );
    }
}
