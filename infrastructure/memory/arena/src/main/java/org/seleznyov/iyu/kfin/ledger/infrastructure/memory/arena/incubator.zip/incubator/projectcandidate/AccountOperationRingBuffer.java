package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.TimeUnit;
import java.util.Arrays;

/**
 * Lock-free ring buffer для операций аккаунта
 * Single-producer, single-consumer паттерн
 */
public class AccountOperationRingBuffer {

    // ===== КОНСТАНТЫ =====
    private static final int DEFAULT_BUFFER_SIZE = 1024;
    private static final long PARK_NANOS = 1_000L; // 1 микросекунда
    private static final long POLL_TIMEOUT_NANOS = 1_000_000L; // 1 миллисекунда

    // ===== ОСНОВНЫЕ ПОЛЯ =====
    private final AccountOperation[] buffer;
    private final int bufferMask;
    private final int bufferSize;

    // ===== SEQUENCE TRACKING =====
    private final AtomicLong writeSequence = new AtomicLong(0L);
    private final AtomicLong readSequence = new AtomicLong(0L);

    // ===== PERFORMANCE OPTIMIZATION =====
    // Кэшированные значения для минимизации volatile reads
    private volatile long cachedReadSequence = 0L;
    private volatile long cachedWriteSequence = 0L;

    // Счетчики для статистики
    private final AtomicLong totalPublished = new AtomicLong(0L);
    private final AtomicLong totalConsumed = new AtomicLong(0L);
    private final AtomicLong publishFailures = new AtomicLong(0L);

    // ===== КОНСТРУКТОРЫ =====

    public AccountOperationRingBuffer() {
        this(DEFAULT_BUFFER_SIZE);
    }

    public AccountOperationRingBuffer(int bufferSize) {
        // Проверяем что размер степень двойки
        if (bufferSize <= 0 || Integer.bitCount(bufferSize) != 1) {
            throw new IllegalArgumentException(
                "Buffer size must be positive power of 2, got: " + bufferSize);
        }

        this.bufferSize = bufferSize;
        this.buffer = new AccountOperation[bufferSize];
        this.bufferMask = bufferSize - 1;

        // Инициализируем кэш
        this.cachedReadSequence = 0L;
        this.cachedWriteSequence = 0L;
    }

    // ===== PRODUCER METHODS (множественные потоки могут вызывать) =====

    /**
     * Пытается опубликовать операцию без блокировки
     * @param operation операция для публикации
     * @return true если успешно опубликовано, false если buffer полный
     */
    public boolean tryPublish(AccountOperation operation) {
        if (operation == null) {
            throw new IllegalArgumentException("Operation cannot be null");
        }

        long currentWrite = writeSequence.get();
        long nextWrite = currentWrite + 1;

        // Быстрая проверка через кэш
        long cachedRead = cachedReadSequence;
        if (nextWrite - cachedRead > bufferSize) {
            // Cache miss - обновляем кэш и проверяем снова
            cachedRead = readSequence.get();
            cachedReadSequence = cachedRead;

            if (nextWrite - cachedRead > bufferSize) {
                publishFailures.incrementAndGet();
                return false; // Buffer действительно полный
            }
        }

        // Пытаемся захватить слот атомарно
        if (!writeSequence.compareAndSet(currentWrite, nextWrite)) {
            publishFailures.incrementAndGet();
            return false; // Другой producer опередил
        }

        // У нас есть эксклюзивный доступ к слоту
        int index = (int) (currentWrite & bufferMask);
        buffer[index] = operation;

        totalPublished.incrementAndGet();
        return true;
    }

    /**
     * Блокирующая публикация с возможностью прерывания
     * @param operation операция для публикации
     * @throws InterruptedException если поток прерван
     */
    public void publish(AccountOperation operation) throws InterruptedException {
        while (!tryPublish(operation)) {
            // Buffer полный - паркуемся на короткое время
            LockSupport.parkNanos(PARK_NANOS);

            // Проверяем прерывание
            if (Thread.currentThread().isInterrupted()) {
                throw new InterruptedException("Publishing interrupted");
            }
        }
    }

    /**
     * Публикация с timeout
     * @param operation операция для публикации
     * @param timeout время ожидания
     * @param unit единица времени
     * @return true если опубликовано, false если timeout
     * @throws InterruptedException если поток прерван
     */
    public boolean publish(AccountOperation operation, long timeout, TimeUnit unit)
        throws InterruptedException {

        long timeoutNanos = unit.toNanos(timeout);
        long deadline = System.nanoTime() + timeoutNanos;

        while (!tryPublish(operation)) {
            long remaining = deadline - System.nanoTime();
            if (remaining <= 0) {
                return false; // Timeout
            }

            // Паркуемся на оставшееся время или PARK_NANOS (что меньше)
            long parkTime = Math.min(remaining, PARK_NANOS);
            LockSupport.parkNanos(parkTime);

            if (Thread.currentThread().isInterrupted()) {
                throw new InterruptedException("Publishing interrupted");
            }
        }

        return true;
    }

    /**
     * Батчевая публикация операций
     * @param operations массив операций
     * @param offset начальная позиция в массиве
     * @param length количество операций для публикации
     * @return количество успешно опубликованных операций
     */
    public int tryPublishBatch(AccountOperation[] operations, int offset, int length) {
        if (operations == null) {
            throw new IllegalArgumentException("Operations array cannot be null");
        }

        if (offset < 0 || length < 0 || offset + length > operations.length) {
            throw new IllegalArgumentException("Invalid offset/length parameters");
        }

        if (length == 0) {
            return 0;
        }

        long currentWrite = writeSequence.get();
        long nextWrite = currentWrite + length;

        // Проверяем достаточно ли места
        long cachedRead = cachedReadSequence;
        if (nextWrite - cachedRead > bufferSize) {
            cachedRead = readSequence.get();
            cachedReadSequence = cachedRead;

            if (nextWrite - cachedRead > bufferSize) {
                // Недостаточно места - пытаемся опубликовать частично
                long available = bufferSize - (currentWrite - cachedRead);
                length = (int) Math.min(length, available);

                if (length <= 0) {
                    publishFailures.incrementAndGet();
                    return 0;
                }

                nextWrite = currentWrite + length;
            }
        }

        // Пытаемся захватить batch слотов
        if (!writeSequence.compareAndSet(currentWrite, nextWrite)) {
            publishFailures.incrementAndGet();
            return 0; // Конкуренция с другими producers
        }

        // Записываем batch операций
        for (int i = 0; i < length; i++) {
            int index = (int) ((currentWrite + i) & bufferMask);
            buffer[index] = operations[offset + i];
        }

        totalPublished.addAndGet(length);
        return length;
    }

    // ===== CONSUMER METHODS (только один dedicated поток) =====

    /**
     * Пытается получить следующую операцию без блокировки
     * @return операция или null если buffer пуст
     */
    public AccountOperation tryConsume() {
        long currentRead = readSequence.get();

        // Быстрая проверка через кэш
        long cachedWrite = cachedWriteSequence;
        if (currentRead >= cachedWrite) {
            // Cache miss - обновляем кэш и проверяем снова
            cachedWrite = writeSequence.get();
            cachedWriteSequence = cachedWrite;

            if (currentRead >= cachedWrite) {
                return null; // Buffer действительно пуст
            }
        }

        // Читаем элемент
        int index = (int) (currentRead & bufferMask);
        AccountOperation operation = buffer[index];

        // Очищаем слот для GC
        buffer[index] = null;

        // Обновляем read sequence
        // lazySet для performance - не нужен полный memory barrier
        readSequence.lazySet(currentRead + 1);

        totalConsumed.incrementAndGet();
        return operation;
    }

    /**
     * Блокирующее получение операции
     * @return следующая операция
     * @throws InterruptedException если поток прерван
     */
    public AccountOperation take() throws InterruptedException {
        AccountOperation operation;

        while ((operation = tryConsume()) == null) {
            // Buffer пуст - паркуемся
            LockSupport.parkNanos(POLL_TIMEOUT_NANOS);

            // Проверяем прерывание
            if (Thread.currentThread().isInterrupted()) {
                throw new InterruptedException("Consuming interrupted");
            }
        }

        return operation;
    }

    /**
     * Получение операции с timeout
     * @param timeout время ожидания
     * @param unit единица времени
     * @return операция или null если timeout
     * @throws InterruptedException если поток прерван
     */
    public AccountOperation poll(long timeout, TimeUnit unit) throws InterruptedException {
        long timeoutNanos = unit.toNanos(timeout);
        long deadline = System.nanoTime() + timeoutNanos;

        AccountOperation operation;
        while ((operation = tryConsume()) == null) {
            long remaining = deadline - System.nanoTime();
            if (remaining <= 0) {
                return null; // Timeout
            }

            // Паркуемся на оставшееся время или POLL_TIMEOUT_NANOS (что меньше)
            long parkTime = Math.min(remaining, POLL_TIMEOUT_NANOS);
            LockSupport.parkNanos(parkTime);

            if (Thread.currentThread().isInterrupted()) {
                throw new InterruptedException("Polling interrupted");
            }
        }

        return operation;
    }

    /**
     * Батчевое чтение операций
     * @param outputArray массив для записи результата
     * @param maxCount максимальное количество для чтения
     * @return количество прочитанных операций
     */
    public int tryConsumeBatch(AccountOperation[] outputArray, int maxCount) {
        if (outputArray == null) {
            throw new IllegalArgumentException("Output array cannot be null");
        }

        if (maxCount <= 0 || maxCount > outputArray.length) {
            throw new IllegalArgumentException("Invalid maxCount parameter");
        }

        long currentRead = readSequence.get();

        // Проверяем доступные элементы
        long cachedWrite = cachedWriteSequence;
        if (currentRead >= cachedWrite) {
            cachedWrite = writeSequence.get();
            cachedWriteSequence = cachedWrite;

            if (currentRead >= cachedWrite) {
                return 0; // Buffer пуст
            }
        }

        // Определяем сколько можем прочитать
        long available = cachedWrite - currentRead;
        int toRead = (int) Math.min(available, maxCount);

        // Читаем batch
        for (int i = 0; i < toRead; i++) {
            int index = (int) ((currentRead + i) & bufferMask);
            outputArray[i] = buffer[index];
            buffer[index] = null; // Очищаем для GC
        }

        // Обновляем read sequence
        readSequence.lazySet(currentRead + toRead);

        totalConsumed.addAndGet(toRead);
        return toRead;
    }

    /**
     * Дренаж всех доступных операций
     * @param outputArray массив для записи результата
     * @return количество прочитанных операций
     */
    public int drainTo(AccountOperation[] outputArray) {
        return tryConsumeBatch(outputArray, outputArray.length);
    }

    // ===== UTILITY METHODS =====

    /**
     * Проверяет есть ли доступные операции для чтения
     */
    public boolean hasAvailableOperations() {
        return readSequence.get() < writeSequence.get();
    }

    /**
     * Возвращает количество элементов в buffer
     */
    public int size() {
        return (int) (writeSequence.get() - readSequence.get());
    }

    /**
     * Проверяет полный ли buffer
     */
    public boolean isFull() {
        return writeSequence.get() - readSequence.get() >= bufferSize;
    }

    /**
     * Проверяет пустой ли buffer
     */
    public boolean isEmpty() {
        return readSequence.get() >= writeSequence.get();
    }

    /**
     * Возвращает емкость buffer
     */
    public int capacity() {
        return bufferSize;
    }

    /**
     * Возвращает коэффициент заполнения (0.0 - 1.0)
     */
    public double getUtilization() {
        int currentSize = size();
        return (double) currentSize / bufferSize;
    }

    /**
     * Очищает buffer (удаляет все операции)
     * ВНИМАНИЕ: Небезопасно при активных producer/consumer
     */
    public void clear() {
        long currentRead = readSequence.get();
        long currentWrite = writeSequence.get();

        // Очищаем все слоты
        for (long seq = currentRead; seq < currentWrite; seq++) {
            int index = (int) (seq & bufferMask);
            buffer[index] = null;
        }

        // Сбрасываем sequences
        readSequence.set(currentWrite);
    }

    /**
     * Принудительное пробуждение consumer потока
     * Полезно при shutdown
     */
    public void wakeupConsumer() {
        // Добавляем специальную операцию для пробуждения
        AccountOperation wakeupOp = AccountOperation.createWakeup();
        tryPublish(wakeupOp);
    }

    // ===== METRICS AND MONITORING =====

    /**
     * Возвращает детальные метрики ring buffer
     */
    public RingBufferMetrics getMetrics() {
        long write = writeSequence.get();
        long read = readSequence.get();
        long published = totalPublished.get();
        long consumed = totalConsumed.get();
        long failures = publishFailures.get();

        return RingBufferMetrics.builder()
            .capacity(bufferSize)
            .currentSize((int) (write - read))
            .writeSequence(write)
            .readSequence(read)
            .utilizationPercent(getUtilization() * 100.0)
            .totalPublished(published)
            .totalConsumed(consumed)
            .publishFailures(failures)
            .successRate(published > 0 ? (double) (published - failures) / published * 100.0 : 0.0)
            .throughputOpsPerSecond(calculateThroughput())
            .build();
    }

    private double calculateThroughput() {
        // Простое вычисление throughput (может быть улучшено)
        long consumed = totalConsumed.get();
        if (consumed == 0) return 0.0;

        // TODO: Реальный расчет на основе времени
        return consumed / 60.0; // Примерно ops/second
    }

    /**
     * Сброс счетчиков статистики
     */
    public void resetMetrics() {
        totalPublished.set(0L);
        totalConsumed.set(0L);
        publishFailures.set(0L);
    }

    // ===== DEBUG AND DIAGNOSTICS =====

    /**
     * Возвращает текущее состояние buffer для отладки
     */
    public String getDebugInfo() {
        long write = writeSequence.get();
        long read = readSequence.get();

        return String.format(
            "RingBuffer[capacity=%d, size=%d, write=%d, read=%d, utilization=%.1f%%, " +
                "published=%d, consumed=%d, failures=%d]",
            bufferSize, (int)(write - read), write, read, getUtilization() * 100.0,
            totalPublished.get(), totalConsumed.get(), publishFailures.get()
        );
    }

    /**
     * Проверка целостности внутреннего состояния
     */
    public boolean isHealthy() {
        long write = writeSequence.get();
        long read = readSequence.get();

        // Базовые проверки целостности
        if (read > write) {
            return false; // Read не может быть больше write
        }

        if (write - read > bufferSize) {
            return false; // Размер не может превышать capacity
        }

        return true;
    }

    @Override
    public String toString() {
        return getDebugInfo();
    }
}