package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator;

import org.springframework.stereotype.Service;

@Service
@Transactional
public class LedgerService {

    private final HotAccountVirtualThreadManager hotAccountManager;
    private final ColdAccountManager coldAccountManager;
    private final AccountClassificationService classificationService;

    public LedgerService(HotAccountVirtualThreadManager hotAccountManager,
                         ColdAccountManager coldAccountManager,
                         AccountClassificationService classificationService) {
        this.hotAccountManager = hotAccountManager;
        this.coldAccountManager = coldAccountManager;
        this.classificationService = classificationService;
    }

    /**
     * Основной метод обработки транзакции
     */
    public CompletableFuture<TransactionResult> processTransaction(TransactionRequest request) {

        // Создаем проводки
        EntryRecord debitEntry = createDebitEntry(request);
        EntryRecord creditEntry = createCreditEntry(request);

        // Определяем типы аккаунтов
        UUID debitAccountId = request.getDebitAccountId();
        UUID creditAccountId = request.getCreditAccountId();

        boolean isDebitHot = classificationService.isHotAccount(debitAccountId);
        boolean isCreditHot = classificationService.isHotAccount(creditAccountId);

        if (isDebitHot && isCreditHot) {
            // Оба аккаунта горячие
            return processHotToHotTransaction(debitEntry, creditEntry);

        } else if (isDebitHot) {
            // Дебет горячий, кредит холодный
            return processHotToColdTransaction(debitEntry, creditEntry);

        } else if (isCreditHot) {
            // Дебет холодный, кредит горячий
            return processColdToHotTransaction(debitEntry, creditEntry);

        } else {
            // Оба аккаунта холодные
            return processColdToColdTransaction(debitEntry, creditEntry);
        }
    }

    private CompletableFuture<TransactionResult> processHotToHotTransaction(
        EntryRecord debitEntry, EntryRecord creditEntry) {

        // Параллельная обработка через виртуальные потоки
        CompletableFuture<Boolean> debitFuture =
            hotAccountManager.processEntry(debitEntry.getAccountId(), debitEntry);

        CompletableFuture<Boolean> creditFuture =
            hotAccountManager.processEntry(creditEntry.getAccountId(), creditEntry);

        return CompletableFuture.allOf(debitFuture, creditFuture)
            .thenApply(v -> TransactionResult.success(debitEntry.getTransactionId()));
    }

    private CompletableFuture<TransactionResult> processHotToColdTransaction(
        EntryRecord debitEntry, EntryRecord creditEntry) {

        // Горячий аккаунт через виртуальный поток
        CompletableFuture<Boolean> debitFuture =
            hotAccountManager.processEntry(debitEntry.getAccountId(), debitEntry);

        // Холодный аккаунт через обычную обработку
        CompletableFuture<Boolean> creditFuture =
            coldAccountManager.processEntry(creditEntry.getAccountId(), creditEntry);

        return CompletableFuture.allOf(debitFuture, creditFuture)
            .thenApply(v -> TransactionResult.success(debitEntry.getTransactionId()));
    }

    private CompletableFuture<TransactionResult> processColdToHotTransaction(
        EntryRecord debitEntry, EntryRecord creditEntry) {

        // Холодный аккаунт через обычную обработку
        CompletableFuture<Boolean> debitFuture =
            coldAccountManager.processEntry(debitEntry.getAccountId(), debitEntry);

        // Горячий аккаунт через виртуальный поток
        CompletableFuture<Boolean> creditFuture =
            hotAccountManager.processEntry(creditEntry.getAccountId(), creditEntry);

        return CompletableFuture.allOf(debitFuture, creditFuture)
            .thenApply(v -> TransactionResult.success(debitEntry.getTransactionId()));
    }

    private CompletableFuture<TransactionResult> processColdToColdTransaction(
        EntryRecord debitEntry, EntryRecord creditEntry) {

        // Оба аккаунта через обычную обработку
        return coldAccountManager.processTransaction(debitEntry, creditEntry);
    }
}