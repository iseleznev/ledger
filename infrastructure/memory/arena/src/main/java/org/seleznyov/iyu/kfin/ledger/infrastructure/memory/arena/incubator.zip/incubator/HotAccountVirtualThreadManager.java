package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.seleznyov.iyu.kfin.ledger.domain.model.entryrecord.EntryRecord;
import org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate.HotAccountContext;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

@Component
@Slf4j
public class HotAccountVirtualThreadManager {

    private final ConcurrentHashMap<UUID, HotAccountContext> hotAccounts = new ConcurrentHashMap<>();
    private final ScheduledExecutorService cleanupScheduler = Executors.newScheduledThreadPool(2);
    private final AtomicBoolean running = new AtomicBoolean(true);

    // Метрики
    private final AtomicLong totalOperationsProcessed = new AtomicLong(0);
    private final AtomicLong totalAccountsCreated = new AtomicLong(0);

    @PostConstruct
    public void initialize() {
        // Запускаем периодическую очистку неактивных аккаунтов
        cleanupScheduler.scheduleWithFixedDelay(
            this::cleanupInactiveAccounts,
            60, 60, TimeUnit.SECONDS
        );

        log.info("HotAccountVirtualThreadManager initialized");
    }

    @PreDestroy
    public void shutdown() {
        log.info("Shutting down HotAccountVirtualThreadManager");

        running.set(false);

        // Останавливаем cleanup scheduler
        cleanupScheduler.shutdown();

        // Gracefully shutdown всех горячих аккаунтов
        List<CompletableFuture<Void>> shutdownFutures = hotAccounts.values().stream()
            .map(context -> CompletableFuture.runAsync(context::shutdown))
            .toList();

        try {
            CompletableFuture.allOf(shutdownFutures.toArray(new CompletableFuture[0]))
                .get(30, TimeUnit.SECONDS);
        } catch (Exception e) {
            log.error("Error during hot accounts shutdown", e);
        }

        hotAccounts.clear();
        log.info("HotAccountVirtualThreadManager shutdown completed");
    }

    // ===== PUBLIC API =====

    /**
     * Обработка проводки для горячего аккаунта
     */
    public CompletableFuture<Boolean> processEntry(UUID accountId, EntryRecord entry) {
        if (!running.get()) {
            return CompletableFuture.failedFuture(
                new IllegalStateException("HotAccountManager is shutting down"));
        }

        HotAccountContext context = getOrCreateAccountContext(accountId);

        return context.addEntry(entry)
            .whenComplete((result, throwable) -> {
                if (throwable == null && result) {
                    totalOperationsProcessed.incrementAndGet();
                }
            });
    }

    /**
     * Получение баланса горячего аккаунта
     */
    public CompletableFuture<Long> getAccountBalance(UUID accountId) {
        HotAccountContext context = hotAccounts.get(accountId);

        if (context == null) {
            // Аккаунт не горячий или не найден
            return CompletableFuture.completedFuture(0L);
        }

        return context.getCurrentBalance();
    }

    /**
     * Принудительный flush батча аккаунта
     */
    public CompletableFuture<Boolean> flushAccount(UUID accountId) {
        HotAccountContext context = hotAccounts.get(accountId);

        if (context == null) {
            return CompletableFuture.completedFuture(false);
        }

        return context.flushBatch();
    }

    /**
     * Получение метрик аккаунта
     */
    public CompletableFuture<AccountMetrics> getAccountMetrics(UUID accountId) {
        HotAccountContext context = hotAccounts.get(accountId);

        if (context == null) {
            return CompletableFuture.completedFuture(null);
        }

        return context.getMetrics();
    }

    /**
     * Проверка является ли аккаунт горячим
     */
    public boolean isHotAccount(UUID accountId) {
        return hotAccounts.containsKey(accountId);
    }

    /**
     * Получение общих метрик менеджера
     */
    public HotAccountManagerMetrics getManagerMetrics() {
        return HotAccountManagerMetrics.builder()
            .activeHotAccounts(hotAccounts.size())
            .totalOperationsProcessed(totalOperationsProcessed.get())
            .totalAccountsCreated(totalAccountsCreated.get())
            .memoryUsageBytes(calculateTotalMemoryUsage())
            .build();
    }

    // ===== PRIVATE METHODS =====

    private HotAccountContext getOrCreateAccountContext(UUID accountId) {
        return hotAccounts.computeIfAbsent(accountId, id -> {
            log.info("Creating new HotAccountContext for account {}", id);
            totalAccountsCreated.incrementAndGet();
            return new HotAccountContext(id);
        });
    }

    private void cleanupInactiveAccounts() {
        if (!running.get()) {
            return;
        }

        long currentTime = System.currentTimeMillis();
        long inactiveThreshold = Duration.ofMinutes(30).toMillis(); // 30 минут неактивности

        List<UUID> accountsToRemove = new ArrayList<>();

        hotAccounts.forEach((accountId, context) -> {
            if (context.isIdle(inactiveThreshold)) {
                accountsToRemove.add(accountId);
            }
        });

        if (!accountsToRemove.isEmpty()) {
            log.info("Cleaning up {} inactive hot accounts", accountsToRemove.size());

            for (UUID accountId : accountsToRemove) {
                HotAccountContext context = hotAccounts.remove(accountId);
                if (context != null) {
                    // Асинхронное завершение работы контекста
                    CompletableFuture.runAsync(() -> {
                        try {
                            context.shutdown();
                            log.debug("Successfully cleaned up hot account {}", accountId);
                        } catch (Exception e) {
                            log.error("Error cleaning up hot account {}", accountId, e);
                        }
                    });
                }
            }
        }
    }

    private long calculateTotalMemoryUsage() {
        return hotAccounts.values().stream()
            .mapToLong(context -> {
                try {
                    AccountMetrics metrics = context.getMetrics().get(100, TimeUnit.MILLISECONDS);
                    return metrics.getMemoryUsageBytes();
                } catch (Exception e) {
                    return 0L;
                }
            })
            .sum();
    }
}