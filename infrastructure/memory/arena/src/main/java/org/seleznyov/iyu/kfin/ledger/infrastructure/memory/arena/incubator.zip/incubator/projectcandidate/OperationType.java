package org.seleznyov.iyu.kfin.ledger.infrastructure.memory.arena.incubator.projectcandidate;

/**
 * Типы операций с аккаунтами
 */
public enum OperationType {

    /**
     * Добавление новой проводки
     */
    ADD_ENTRY("Добавление проводки"),

    /**
     * Получение текущего баланса
     */
    GET_BALANCE("Получение баланса"),

    /**
     * Принудительный flush батча
     */
    FLUSH_BATCH("Сброс батча"),

    /**
     * Получение метрик аккаунта
     */
    GET_METRICS("Получение метрик"),

    /**
     * Получение размера батча
     */
    GET_BATCH_SIZE("Получение размера батча"),

    /**
     * Получение детального баланса
     */
    GET_BALANCE_DETAILED("Детальный баланс"),

    /**
     * Операция пробуждения (служебная)
     */
    WAKEUP("Пробуждение"),

    /**
     * Операция завершения работы (служебная)
     */
    SHUTDOWN("Завершение работы");

    private final String description;

    OperationType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Проверяет является ли операция служебной
     */
    public boolean isSystemOperation() {
        return this == WAKEUP || this == SHUTDOWN;
    }

    /**
     * Проверяет является ли операция запросом данных
     */
    public boolean isReadOperation() {
        return this == GET_BALANCE ||
            this == GET_METRICS ||
            this == GET_BATCH_SIZE ||
            this == GET_BALANCE_DETAILED;
    }

    /**
     * Проверяет является ли операция изменением данных
     */
    public boolean isWriteOperation() {
        return this == ADD_ENTRY || this == FLUSH_BATCH;
    }

    @Override
    public String toString() {
        return description;
    }
}
